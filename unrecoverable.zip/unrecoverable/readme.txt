Description: Data recovery softwares can easily recover the deleted data from the Hard Disk. Develop an executable code snippet for Microsoft Windows environment to Securely Delete the given file. Deleted file should not be recoverable using any Forensic tool. Any of the common secure deletion practices may be used

The code snippet is here, i have run it on my pc, with all the necessary files.
You can check it out, by running on your PC.

Comments specify the working scenario
